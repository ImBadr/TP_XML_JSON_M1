package exo3;

public enum Gender {
    F,
    M
}
